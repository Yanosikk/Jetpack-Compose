package com.example.lab2_275808

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.lab2_275808.ui.theme.LAB2_275808Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager

        setContent {
            LAB2_275808Theme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { paddingValues ->
                    AppContent(
                        sensorManager = sensorManager,
                        modifier = Modifier.padding(paddingValues)
                    )
                }
            }
        }
    }
}

@Composable
fun AppContent(sensorManager: SensorManager, modifier: Modifier = Modifier) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "menu",
        modifier = modifier
    ) {
        composable("menu") { SensorMenu(navController) }
        composable("accelerometer") {
            SensorScreen(sensorManager, Sensor.TYPE_ACCELEROMETER, "Akcelerometr", navController)
        }
        composable("light") {
            SensorScreen(sensorManager, Sensor.TYPE_LIGHT, "Światło", navController)
        }
        composable("gyroscope") {
            SensorScreen(sensorManager, Sensor.TYPE_GYROSCOPE, "Żyroskop", navController)
        }
        composable("temperature") {
            SensorScreen(sensorManager, Sensor.TYPE_AMBIENT_TEMPERATURE, "Temperatura", navController)
        }
    }
}

@Composable
fun SensorMenu(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Sensory",
            fontSize = 30.sp,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        val sensors = listOf(
            "Akcelerometr" to "accelerometer",
            "Światło" to "light",
            "Żyroskop" to "gyroscope",
            "Temperatura" to "temperature" // Dodano nowy sensor
        )

        sensors.forEach { (name, route) ->
            Button(
                onClick = { navController.navigate(route) },
                modifier = Modifier
                    .padding(vertical = 8.dp)
                    .fillMaxWidth(0.7f)
            ) {
                Text(
                    text = name,
                    fontSize = 20.sp,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}

@Composable
fun SensorScreen(sensorManager: SensorManager, sensorType: Int, title: String, navController: NavController) {
    var sensorData by remember { mutableStateOf("Brak danych") }

    DisposableEffect(Unit) {
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.let {
                    sensorData = it.values.joinToString(", ") { value -> "%.2f".format(value) }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        val sensor = sensorManager.getDefaultSensor(sensorType)
        if (sensor != null) {
            sensorManager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        } else {
            sensorData = "Czujnik niedostępny"
        }

        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = title, fontSize = 24.sp, modifier = Modifier.padding(bottom = 16.dp))
        Text(text = sensorData, fontSize = 18.sp)

        Button(
            onClick = { navController.navigateUp() },
            modifier = Modifier
                .padding(top = 32.dp)
                .fillMaxWidth(0.7f)
        ) {
            Text("Powrót", fontSize = 18.sp)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MenuPreview() {
    LAB2_275808Theme {
        SensorMenu(navController = rememberNavController())
    }
}
