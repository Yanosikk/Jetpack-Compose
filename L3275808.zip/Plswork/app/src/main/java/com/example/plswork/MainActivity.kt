@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.plswork

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.plswork.ui.theme.PlsworkTheme
import com.google.firebase.database.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val firebaseUrl = "https://plswork-445ac-default-rtdb.europe-west1.firebasedatabase.app/"
        database = FirebaseDatabase.getInstance(firebaseUrl).reference
        auth = FirebaseAuth.getInstance()

        enableEdgeToEdge()
        setContent {
            PlsworkTheme {
                val navController = rememberNavController()

                NavHost(
                    navController = navController,
                    startDestination = "login"
                ) {
                    composable("login") {
                        LoginScreen(navController, auth)
                    }
                    composable("home") {
                        HomeScreen(navController, database)
                    }
                    composable("addData") {
                        AddDataScreen(navController, database)
                    }
                }
            }
        }
    }
}

@Composable
fun LoginScreen(navController: NavHostController, auth: FirebaseAuth) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            SmallTopAppBar(title = { Text("Login") })
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            TextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )
            TextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )

            Button(
                onClick = {
                    auth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                navController.navigate("home")
                            } else {
                                errorMessage = task.exception?.message ?: "Login failed"
                            }
                        }
                },
                modifier = Modifier.padding(16.dp)
            ) {
                Text("Login")
            }

            Button(
                onClick = {
                    auth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                navController.navigate("home")
                            } else {
                                errorMessage = task.exception?.message ?: "Registration failed"
                            }
                        }
                },
                modifier = Modifier.padding(16.dp)
            ) {
                Text("Register")
            }

            if (errorMessage.isNotEmpty()) {
                Text(text = errorMessage, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
fun HomeScreen(navController: NavHostController, database: DatabaseReference) {
    var dataFromFirebase by remember { mutableStateOf("Loading...") }

    LaunchedEffect(Unit) {
        database.child("users").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val users = snapshot.children.joinToString("\n") {
                    val name = it.child("name").value.toString()
                    val age = it.child("age").value.toString()
                    "$name, age: $age"
                }
                dataFromFirebase = users
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("Firebase", "Failed to load data: ${error.message}")
                dataFromFirebase = "Error loading data."
            }
        })
    }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Home Screen") },
                actions = {
                    TextButton(onClick = { navController.navigate("addData") }) {
                        Text("Add Data")
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            Text(text = dataFromFirebase)
        }
    }
}

@Composable
fun AddDataScreen(navController: NavHostController, database: DatabaseReference) {
    var inputText by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Add Data Screen") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                label = { Text("Enter some data") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )

            Button(
                onClick = {
                    val timestamp = System.currentTimeMillis()
                    database.child("usage").child(timestamp.toString()).setValue(inputText)
                        .addOnSuccessListener {
                            statusMessage = "Data sent successfully!"
                        }
                        .addOnFailureListener { e ->
                            statusMessage = "Failed to send data: ${e.message}"
                        }
                },
                modifier = Modifier.padding(16.dp)
            ) {
                Text("Send Data")
            }

            if (statusMessage.isNotEmpty()) {
                Text(text = statusMessage, modifier = Modifier.padding(16.dp))
            }
        }
    }
}
