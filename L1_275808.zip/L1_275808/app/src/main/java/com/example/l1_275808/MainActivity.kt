package com.example.l1_275808
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.l1_275808.ui.theme.L1_275808Theme
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            L1_275808Theme {
                MainApp()
            }
        }
    }
}

sealed class Screen(val route: String) {
    object Greeting : Screen("greeting")
    object Second : Screen("second/{name}") {
        fun createRoute(name: String): String {
            val encodedName = URLEncoder.encode(name, StandardCharsets.UTF_8.toString())
            return "second/$encodedName"
        }
    }
    object Third : Screen("third/{message}") {
        fun createRoute(message: String): String {
            val encodedMessage = URLEncoder.encode(message, StandardCharsets.UTF_8.toString())
            return "third/$encodedMessage"
        }
    }
}

@Composable
fun MainApp() {
    val navController = rememberNavController()

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Greeting.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Greeting.route) {
                GreetingScreen(navController = navController)
            }
            composable(
                route = Screen.Second.route,
                arguments = listOf(navArgument("name") { type = NavType.StringType })
            ) { backStackEntry ->
                val name = backStackEntry.arguments?.getString("name")
                SecondScreen(navController = navController, name = name)
            }
            composable(
                route = Screen.Third.route,
                arguments = listOf(navArgument("message") { type = NavType.StringType })
            ) { backStackEntry ->
                val message = backStackEntry.arguments?.getString("message")
                ThirdScreen(navController = navController, message = message)
            }
        }
    }
}

@Composable
fun GreetingScreen(navController: NavHostController) {
    var name by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        TextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Wpisz coś") },
            colors = TextFieldDefaults.colors(
                focusedTextColor = Color.Black,
                unfocusedTextColor = Color.Black,
                focusedContainerColor = Color.LightGray,
                unfocusedContainerColor = Color.LightGray,
                focusedIndicatorColor = Color.Blue,
                unfocusedIndicatorColor = Color.Gray
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (name.isNotEmpty()) {
                    navController.navigate(Screen.Second.createRoute(name))
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Idź do ekranu drugiego")
        }
    }
}

@Composable
fun SecondScreen(navController: NavHostController, name: String?) {
    var customMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Cześć, ${name ?: "Guest"}!",
            style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = customMessage,
            onValueChange = { customMessage = it },
            label = { Text("Wiadomość") },
            colors = TextFieldDefaults.colors(
                focusedTextColor = Color.Black,
                unfocusedTextColor = Color.Black,
                focusedContainerColor = Color.LightGray,
                unfocusedContainerColor = Color.LightGray,
                focusedIndicatorColor = Color.Blue,
                unfocusedIndicatorColor = Color.Gray
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (customMessage.isNotEmpty()) {
                    navController.navigate(Screen.Third.createRoute(customMessage))
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Idź do ekranu trzeciego")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { navController.navigate(Screen.Greeting.route) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Powrót do ekranu powitalnego")
        }
    }
}

@Composable
fun ThirdScreen(navController: NavHostController, message: String?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = message ?: "No message provided",
            style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { navController.navigate(Screen.Greeting.route) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Powrót do ekranu powitalnego")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingScreenPreview() {
    L1_275808Theme {
        GreetingScreen(navController = rememberNavController())
    }
}